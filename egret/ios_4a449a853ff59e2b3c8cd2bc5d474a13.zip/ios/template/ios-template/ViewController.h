#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

- (instancetype)initWithEAGLView:(UIView*)eaglView;

@end
